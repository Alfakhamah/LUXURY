
import telebot
import random

bot = telebot.TeleBot("ضع_توكن_البوت_هنا")

nokat = [
    "مرة واحد دخل البنك وقال لهم أعطوني فلوسي قبل ما أتذكر إني ما عنديش حساب 😅",
    "في واحد تزوج وحدة اسمها نفس اسم أمه، قال له صاحبه: كيف بتناديها؟ قال: غيرت اسم أمي 😂"
]

fakhamah = [
    "الفخامة ليست مظهراً.. بل سلوك يليق بك 👑",
    "كن كالماس لا يراه إلا من يستحق 🌟"
]

mazaj = [
    "مزاجك رايق؟ زوده فخامة 🌤️",
    "لا تشيل هم.. أنت في مستوى أعلى من القلق 😌"
]

info = [
    "هل تعلم؟ الذهب لا يصدأ لأنه لا يتفاعل مع الأكسجين!",
    "الضحك مفيد للقلب 😂❤️"
]

images = [
    "https://i.imgur.com/f4rW6mF.jpg",
    "https://i.imgur.com/Z2G4DCE.jpg",
    "https://i.imgur.com/VnD2xEI.jpg"
]

@bot.message_handler(commands=['start'])
def welcome(message):
    bot.reply_to(message, "أهلاً بك في LUXURY BOT ✨\nاكتب أي أمر:\n/نكتة\n/فخامة\n/مزاج\n/معلومة\n/صورة")

@bot.message_handler(commands=['نكتة'])
def joke(message):
    bot.reply_to(message, random.choice(nokat))

@bot.message_handler(commands=['فخامة'])
def classy(message):
    bot.reply_to(message, random.choice(fakhamah))

@bot.message_handler(commands=['مزاج'])
def mood(message):
    bot.reply_to(message, random.choice(mazaj))

@bot.message_handler(commands=['معلومة'])
def fact(message):
    bot.reply_to(message, random.choice(info))

@bot.message_handler(commands=['صورة'])
def photo(message):
    bot.send_photo(message.chat.id, random.choice(images))

bot.polling()
